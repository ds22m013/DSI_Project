

postgres_host='localhost'
postgres_port='5432'
postgres_user = 'postgres'
postgres_password = 'DSIholiday'